
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  TextInput, StyleSheet, SafeAreaView
} from 'react-native';

const services = [
  ['🛒', 'Grocery'],
  ['📦', 'Parcel'],
  ['💊', 'Pharmacy'],
  ['🛍️', 'Personal Shopping'],
  ['🚚', 'Business Logistics']
];

export default function App() {
  const [page, setPage] = useState('Home');
  const [service, setService] = useState('');
  const [details, setDetails] = useState('');
  const [address, setAddress] = useState('Greater Noida');
  const [payment, setPayment] = useState('UPI');
  const [orders, setOrders] = useState([]);

  const blue = '#1769E8';

  const btn = (label, action) => (
    <TouchableOpacity style={s.button} onPress={action}>
      <Text style={s.buttonText}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Text style={s.logo}>SPEEDO</Text>
        <Text style={s.tagline}>Anything. Anywhere. Delivered.</Text>
      </View>

      {page === 'Home' && (
        <ScrollView style={s.body}>
          <Text style={s.location}>📍 {address}</Text>
          <Text style={s.hero}>Your local delivery partner.</Text>
          <Text style={s.subtitle}>
            What would you like delivered today?
          </Text>

          {services.map(([emoji, name]) => (
            <TouchableOpacity
              key={name}
              style={s.card}
              onPress={() => {
                setService(name);
                setDetails('');
                setPage('Request');
              }}>
              <Text style={s.service}>{emoji}  {name}</Text>
              <Text style={s.link}>Book now →</Text>
            </TouchableOpacity>
          ))}
          {btn('My Orders', () => setPage('Orders'))}
          {btn('My Profile', () => setPage('Profile'))}
        </ScrollView>
      )}

      {page === 'Request' && (
        <ScrollView style={s.body}>
          <Text style={s.hero}>{service}</Text>
          <Text style={s.subtitle}>Enter your requirements</Text>
          <TextInput
            style={s.input}
            placeholder="Describe what you need..."
            multiline
            value={details}
            onChangeText={setDetails}
          />
          <Text style={s.subtitle}>Delivery address</Text>
          <TextInput
            style={s.input}
            value={address}
            onChangeText={setAddress}
          />
          <Text style={s.subtitle}>Payment preference</Text>
          <View style={s.row}>
            {['UPI', 'Online', 'Cash'].map(p => (
              <TouchableOpacity
                key={p}
                onPress={() => setPayment(p)}
                style={[s.pay, payment === p && s.selected]}>
                <Text>{p}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {btn('Place Demo Request', () => {
            if (!details.trim()) return;
            setOrders([
              ...orders,
              { service, details, address, payment }
            ]);
            setPage('Orders');
          })}
          {btn('Back', () => setPage('Home'))}
        </ScrollView>
      )}

      {page === 'Orders' && (
        <ScrollView style={s.body}>
          <Text style={s.hero}>My Orders</Text>
          {orders.length === 0
            ? <Text style={s.subtitle}>No orders yet.</Text>
            : orders.map((o, i) => (
              <View key={i} style={s.card}>
                <Text style={s.service}>{o.service}</Text>
                <Text>{o.details}</Text>
                <Text>📍 {o.address}</Text>
                <Text>Payment: {o.payment}</Text>
                <Text style={s.link}>Demo request received</Text>
              </View>
            ))}
          {btn('Home', () => setPage('Home'))}
        </ScrollView>
      )}

      {page === 'Profile' && (
        <View style={s.body}>
          <Text style={s.hero}>My Profile</Text>
          <Text style={s.subtitle}>Speedo Guest Customer</Text>
          <TextInput
            style={s.input}
            value={address}
            onChangeText={setAddress}
            placeholder="Delivery location"
          />
          {btn('Home', () => setPage('Home'))}
        </View>
      )}

      <View style={s.footer}>
        <Text style={s.footerText}>SPEEDO • GREATER NOIDA</Text>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F4F7FC' },
  header: { backgroundColor: '#102447', padding: 22 },
  logo: { color: 'white', fontSize: 29, fontWeight: '900' },
  tagline: { color: '#BFD5FF', marginTop: 4 },
  body: { padding: 18, flex: 1 },
  location: { color: '#1769E8', fontWeight: 'bold', marginBottom: 20 },
  hero: { fontSize: 25, fontWeight: '900', color: '#102447', marginBottom: 10 },
  subtitle: { fontSize: 14, color: '#68778C', marginVertical: 12 },
  card: { backgroundColor: 'white', padding: 17, borderRadius: 14, marginBottom: 12 },
  service: { fontSize: 17, fontWeight: 'bold', color: '#102447' },
  link: { color: '#1769E8', marginTop: 8, fontWeight: 'bold' },
  button: { backgroundColor: '#1769E8', padding: 15, borderRadius: 12, marginVertical: 7, alignItems: 'center' },
  buttonText: { color: 'white', fontWeight: 'bold' },
  input: { backgroundColor: 'white', padding: 15, borderRadius: 12, marginVertical: 8, minHeight: 50 },
  row: { flexDirection: 'row', gap: 8 },
  pay: { backgroundColor: 'white', padding: 13, borderRadius: 10 },
  selected: { borderWidth: 2, borderColor: '#1769E8' },
  footer: { padding: 13, alignItems: 'center', backgroundColor: 'white' },
  footerText: { color: '#1769E8', fontWeight: 'bold', fontSize: 11 }
});
